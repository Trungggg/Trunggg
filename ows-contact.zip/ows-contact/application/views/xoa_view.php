<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="refresh" content="1;url=../../contact">
	<title>Document</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">  
	<script type="text/javascript" src="<?= base_url() ?>vendor/bootstrap.js"></script>
	<link rel="stylesheet" href="<?= base_url() ?>vendor/bootstrap.css">
</head>
<body>
	<div class="container">
		<div class="row text-xs-center">
			<div class="alert alert-success" role="alert">
				ban da xoa<strong>&nbsp;Thanh cong!</strong>
			</div>
		</div>
	</div>
	
</body>
</html>